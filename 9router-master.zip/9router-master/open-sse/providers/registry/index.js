// Auto-generated: static imports for all registry entries
import p0 from "./alicode-intl.js";
import p1 from "./alicode.js";
import p2 from "./anthropic.js";
import p3 from "./antigravity.js";
import p4 from "./assemblyai.js";
import p5 from "./aws-polly.js";
import p6 from "./azure.js";
import p7 from "./black-forest-labs.js";
import p8 from "./blackbox.js";
import p9 from "./brave-search.js";
import p10 from "./byteplus.js";
import p11 from "./cartesia.js";
import p12 from "./cerebras.js";
import p13 from "./chutes.js";
import p14 from "./claude.js";
import p15 from "./cline.js";
import p16 from "./clinepass.js";
import p17 from "./cloudflare-ai.js";
import p18 from "./codebuddy-cn.js";
import p19 from "./codex.js";
import p20 from "./cohere.js";
import p21 from "./comfyui.js";
import p22 from "./commandcode.js";
import p23 from "./coqui.js";
import p24 from "./cursor.js";
import p25 from "./deepgram.js";
import p26 from "./deepseek.js";
import p27 from "./edge-tts.js";
import p28 from "./elevenlabs.js";
import p29 from "./exa.js";
import p30 from "./fal-ai.js";
import p31 from "./featherless.js";
import p32 from "./firecrawl.js";
import p33 from "./fireworks.js";
import p34 from "./gemini-cli.js";
import p35 from "./gemini.js";
import p36 from "./github.js";
import p37 from "./gitlab.js";
import p38 from "./glm-cn.js";
import p39 from "./glm.js";
import p40 from "./google-pse.js";
import p41 from "./google-tts.js";
import p42 from "./grok-cli.js";
import p43 from "./grok-web.js";
import p44 from "./groq.js";
import p45 from "./huggingface.js";
import p46 from "./hyperbolic.js";
import p47 from "./iflow.js";
import p48 from "./inworld.js";
import p49 from "./jina-ai.js";
import p50 from "./jina-reader.js";
import p51 from "./kilocode.js";
import p52 from "./kimchi.js";
import p53 from "./kimi.js";
import p54 from "./kiro.js";
import p55 from "./linkup.js";
import p56 from "./local-device.js";
import p57 from "./mimo-free.js";
import p58 from "./minimax-cn.js";
import p59 from "./minimax.js";
import p60 from "./mistral.js";
import p61 from "./mmf.js";
import p62 from "./nanobanana.js";
import p63 from "./nebius.js";
import p64 from "./nvidia.js";
import p65 from "./ollama-local.js";
import p66 from "./ollama.js";
import p123 from "./ollama-search.js";
import p67 from "./openai.js";
import p68 from "./opencode-go.js";
import p68z from "./opencode-zen.js";
import p69 from "./opencode.js";
import p70 from "./openrouter.js";
import p71 from "./perplexity-web.js";
import p72 from "./perplexity.js";
import p73 from "./perplexity-agent.js";
import p74 from "./playht.js";
import p75 from "./qoder.js";
import p124 from "./qoder-cn.js";
import p77 from "./recraft.js";
import p78 from "./runwayml.js";
import p79 from "./sdwebui.js";
import p80 from "./searchapi.js";
import p81 from "./searxng.js";
import p82 from "./serper.js";
import p83 from "./siliconflow.js";
import p84 from "./stability-ai.js";
import p85 from "./tavily.js";
import p86 from "./together.js";
import p87 from "./topaz.js";
import p88 from "./tortoise.js";
import p89 from "./venice.js";
import p90 from "./vercel-ai-gateway.js";
import p91 from "./vertex-partner.js";
import p92 from "./vertex.js";
import p93 from "./volcengine-ark.js";
import p94 from "./voyage-ai.js";
import p95 from "./xai.js";
import p96 from "./xiaomi-mimo.js";
import p97 from "./xiaomi-tokenplan.js";
import p98 from "./youcom.js";
import p99 from "./alims-intl.js";
import p100 from "./codebuddy-intl.js";
// Temporarily hidden — no tool calling support (trae SOLO agent / windsurf gRPC skip ToolCallChunk).
// Re-enable by uncommenting both the import and the array entry below.
// import p102 from "./trae.js";
import p103 from "./zed.js";
import p105 from "./api-airforce.js";
import p106 from "./baidu.js";
import p107 from "./bazaarlink.js";
import p108 from "./bluesminds.js";
import p109 from "./kilo-gateway.js";
import p110 from "./llm7.js";
import p111 from "./sambanova.js";
import p112 from "./tencent.js";
import p113 from "./morph.js";
// import p114 from "./devin-cli.js";
// import p104 from "./windsurf.js";
import p115 from "./poolside.js";
import p116 from "./tokenrouter.js";
import p117 from "./selfhosted-stt.js";
import p118 from "./selfhosted-tts.js";
import p119 from "./selfhosted-embedding.js";
import p120 from "./fish-audio.js";
import p121 from "./alitp-intl.js";
import p122 from "./xquik.js";
import p125 from "./tokenharbor.js";
import p126 from "./dahl.js";
import p127 from "./atria.js";
import p129 from "./agnes.js";
import p130 from "./bai.js";
import p131 from "./tinyfish.js";
import p132 from "./v1m.js";
import p133 from "./muse.js";
import p134 from "./minimax-code.js";
import p135 from "./minimax-code-global.js";
import p136 from "./bedrock.js";
import p137 from "./bedrock-xai.js";
export default [
  p0,
  p1,
  p2,
  p3,
  p4,
  p5,
  p6,
  p7,
  p8,
  p9,
  p10,
  p11,
  p12,
  p13,
  p14,
  p15,
  p16,
  p17,
  p18,
  p19,
  p20,
  p21,
  p22,
  p23,
  p24,
  p25,
  p26,
  p27,
  p28,
  p29,
  p30,
  p31,
  p32,
  p33,
  p34,
  p35,
  p36,
  p37,
  p38,
  p39,
  p40,
  p41,
  p42,
  p43,
  p44,
  p45,
  p46,
  p47,
  p48,
  p49,
  p50,
  p51,
  p52,
  p53,
  p54,
  p55,
  p56,
  p57,
  p58,
  p59,
  p60,
  p61,
  p62,
  p63,
  p64,
  p65,
  p66,
  p123,
  p124,
  p67,
  p68,
  p68z,
  p69,
  p70,
  p71,
  p72,
  p73,
  p74,
  p75,
  p77,
  p78,
  p79,
  p80,
  p81,
  p82,
  p83,
  p84,
  p85,
  p86,
  p87,
  p88,
  p89,
  p90,
  p91,
  p92,
  p93,
  p94,
  p95,
  p96,
  p97,
  p98,
  p99,
  p100,
  // p102, // trae — hidden, no tool calling
  p103,
  p105,
  p106,
  p107,
  p108,
  p109,
  p110,
  p111,
  p112,
  p113,
  // p114, // devin-cli — hidden, spawns local agent with shell/fs access
  // p104, // windsurf — hidden, no tool calling
  p115,
  p116,
  p117,
  p118,
  p119,
  p120,
  p121,
  p122,
  p125,
  p126,
  p127,
  p129,
  p130,
  p131,
  p132,
  p133,
  p134,
  p135,
  p136,
  p137,
];
